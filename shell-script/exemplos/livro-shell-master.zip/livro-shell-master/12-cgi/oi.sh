#!/bin/bash
# oi.sh

echo Content-type: text/plain
echo
echo Oi
