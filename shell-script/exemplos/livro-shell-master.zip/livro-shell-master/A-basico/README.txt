Shell Script Básico
===================

Se você está estudando o shell básico, eu tenho um único conselho:

**NÃO VEJA AS RESPOSTAS DOS EXERCÍCIOS!**

Primeiro tente fazê-los você mesmo, consulte o livro, leia man pages,
arrisque na linha de comando. Não desista.

Só veja a resposta de algum exercício caso você já tenha conseguido
fazê-lo, para poder comparar a sua resposta com a do livro.

Se elas forem diferentes, não se preocupe. Não há certo ou errado, há
programas que funcionam e programas que não funcionam. O importante é
que seu programa faça o que o exercício pediu.

Lembre-se: Ver a resposta sem tentar fazer é para os fracos :)

