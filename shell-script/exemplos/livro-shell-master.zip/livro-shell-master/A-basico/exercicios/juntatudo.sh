#!/bin/bash

echo $* | tr -d ' '
